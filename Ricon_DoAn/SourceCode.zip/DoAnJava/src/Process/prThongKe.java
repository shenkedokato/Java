/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Process;

import ConnectDB_Notify.KetNoiDatabase;
import Model.DoanhThu;
import java.sql.Connection;
import java.sql.CallableStatement;
import java.sql.ResultSet;

/**
 *
 * @author ASUS
 */
public class prThongKe {
    public void tkdtThang(DoanhThu dt) throws Exception{
    }
}
