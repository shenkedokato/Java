/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ConnectDB_Notify;

import Model.DangNhap;

/**
 *
 * @author ASUS
 */
public class ChiaseDuLieu {
    public static DangNhap nguoiDangnhap;
}
